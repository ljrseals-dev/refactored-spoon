"""Regression tests for provider isolation and honest answering."""

from __future__ import annotations

import pytest

from offline_doc_mcp.engine import MODES, Engine, Mode

OFFLINE_MODES = ["CLASSICAL", "ARCHIVE", "AUTO"]
PROVIDER_MODES = ["HYBRID", "RESEARCH", "AUDIT"]
NO_RULE_QUESTION = "zzqx unmatched gibberish question 12345"

PASSAGE = {
    "content": "A Hopfield network stores patterns as attractors.",
    "title": "Hopfield notes",
    "path": "data/hopfield.txt",
    "chunk_index": 2,
}


class RecordingProvider:
    def __init__(self, reply="fake answer from provider"):
        self.calls = 0
        self.reply = reply
        self.last_user = ""

    def complete(self, system: str, user: str) -> str:
        self.calls += 1
        self.last_user = user
        return self.reply


def test_provider_policy_matches_spec():
    assert {m.value for m, s in MODES.items() if s.allows_provider} == set(PROVIDER_MODES)
    assert not MODES[Mode.CLASSICAL].allows_provider
    assert not MODES[Mode.ARCHIVE].allows_provider


@pytest.mark.parametrize("mode", OFFLINE_MODES)
def test_offline_modes_never_call_injected_provider(mode):
    provider = RecordingProvider()
    answer = Engine(provider=provider, archive_search=lambda q: [PASSAGE]).ask(
        NO_RULE_QUESTION, mode=mode
    )
    assert provider.calls == 0
    assert answer.classical is True
    assert answer.truth_status == "UNKNOWN"


@pytest.mark.parametrize("mode", OFFLINE_MODES)
def test_offline_modes_ignore_require_llm(mode):
    provider = RecordingProvider()
    answer = Engine(provider=provider, require_llm=True).ask(NO_RULE_QUESTION, mode=mode)
    assert provider.calls == 0
    assert answer.error is None


@pytest.mark.parametrize("mode", PROVIDER_MODES)
def test_provider_modes_call_provider(mode):
    provider = RecordingProvider()
    answer = Engine(provider=provider).ask(NO_RULE_QUESTION, mode=mode)
    assert provider.calls == 1
    assert answer.classical is False


@pytest.mark.parametrize("mode", PROVIDER_MODES)
def test_require_llm_without_provider_is_an_error(mode):
    answer = Engine(require_llm=True).ask(NO_RULE_QUESTION, mode=mode)
    assert answer.error == "provider_required"


@pytest.mark.parametrize("mode", OFFLINE_MODES)
def test_offline_answers_carry_provenance(mode):
    answer = Engine(archive_search=lambda q: [PASSAGE]).ask("hopfield", mode=mode)
    assert "attractors" in answer.answer
    assert answer.sources == ["Hopfield notes (data/hopfield.txt, chunk 2)"]
    assert answer.evidence[0]["path"] == "data/hopfield.txt"
    assert answer.evidence[0]["chunk_index"] == 2


def test_no_documents_says_so_and_is_unknown():
    answer = Engine().ask(NO_RULE_QUESTION, mode="ARCHIVE")
    assert "No relevant" in answer.answer
    assert answer.sources == [] and answer.evidence == []
    assert answer.truth_status == "UNKNOWN"


def test_provider_truth_status_is_never_invented():
    answer = Engine(provider=RecordingProvider("a claim with no status")).ask("q", "HYBRID")
    assert answer.truth_status == "UNKNOWN"


def test_provider_truth_status_is_parsed_and_stripped():
    reply = "Supported claim.\n\nTRUTH_STATUS: PLAUSIBLE"
    answer = Engine(provider=RecordingProvider(reply)).ask("q", "HYBRID")
    assert answer.truth_status == "PLAUSIBLE"
    assert "TRUTH_STATUS" not in answer.answer


def test_invalid_truth_status_falls_back_to_unknown():
    reply = "Claim.\nTRUTH_STATUS: DEFINITELY_TRUE"
    assert Engine(provider=RecordingProvider(reply)).ask("q", "AUDIT").truth_status == "UNKNOWN"


def test_provider_receives_retrieved_sources():
    provider = RecordingProvider()
    Engine(provider=provider, archive_search=lambda q: [PASSAGE]).ask("q", "HYBRID")
    assert "data/hopfield.txt" in provider.last_user


def test_provider_failure_is_structured_not_an_answer():
    class Boom:
        def complete(self, system, user):
            raise RuntimeError("secret-key-abc123")

    answer = Engine(provider=Boom()).ask("q", "HYBRID")
    assert answer.error == "provider_error: RuntimeError"
    assert answer.truth_status == "UNKNOWN"
    assert "secret-key-abc123" not in answer.answer
