"""Tests for chunking, the FTS index, retrieval wiring and the HTML UI."""

from __future__ import annotations

import pytest

from offline_doc_mcp.engine import Engine, make_archive_search
from offline_doc_mcp.processing import LocalIndex, chunk_text
from offline_doc_mcp.processing.indexer import fts_query

TEXT = "The Hopfield network stores patterns as attractors. " * 60


@pytest.fixture
def idx(tmp_path):
    return LocalIndex(tmp_path / "index.db")


def test_chunker_terminates_without_rescanning_tail():
    chunks = chunk_text("word " * 5000, chunk_size=1200, overlap=150)
    assert 5 <= len(chunks) <= 30
    assert all(len(c) >= 200 for c in chunks)


@pytest.mark.parametrize("size,overlap", [(0, 0), (100, 100), (100, -1)])
def test_chunker_rejects_bad_parameters(size, overlap):
    with pytest.raises(ValueError):
        chunk_text(TEXT, chunk_size=size, overlap=overlap)


def test_reindexing_replaces_instead_of_duplicating(idx, tmp_path):
    path = tmp_path / "a.txt"
    n = idx.add_document(path, TEXT)
    idx.add_document(path, TEXT)
    assert idx.stats() == {"documents": 1, "chunks": n}


def test_reindexing_with_changed_text_drops_old_chunks(idx, tmp_path):
    path = tmp_path / "a.txt"
    idx.add_document(path, TEXT)
    idx.add_document(path, "Kohonen maps organise inputs topologically. " * 60)
    assert idx.search("Hopfield") == []
    assert idx.search("Kohonen")


@pytest.mark.parametrize(
    "query", ["what's a hopfield", "C++", 'hopfield "', "a-b", "NOT", "x AND", "<script>", "", "   "]
)
def test_search_never_raises_on_arbitrary_text(idx, tmp_path, query):
    idx.add_document(tmp_path / "a.txt", TEXT)
    assert isinstance(idx.search(query), list)


def test_search_results_carry_provenance_and_limit_is_clamped(idx, tmp_path):
    idx.add_document(tmp_path / "a.txt", TEXT)
    results = idx.search("hopfield", limit=10_000)
    assert results and len(results) <= 50
    assert {"title", "path", "doc_id", "chunk_index", "content"} <= results[0].keys()
    assert idx.search("hopfield", limit=-5)  # clamped to >= 1, not an error


def test_fts_query_quotes_tokens():
    assert fts_query("what's NOT a-b") == '"what" "s" "NOT" "a" "b"'


def test_engine_answers_from_index_with_sources(idx, tmp_path):
    idx.add_document(tmp_path / "hop.txt", TEXT, title="Hopfield notes")
    engine = Engine(archive_search=make_archive_search(idx))
    answer = engine.ask("hopfield attractors", mode="ARCHIVE")
    assert answer.sources and "Hopfield notes" in answer.sources[0]
    assert answer.classical is True


def test_html_ui_escapes_query_and_content(idx, tmp_path, monkeypatch):
    pytest.importorskip("fastapi")
    from offline_doc_mcp import html_server

    idx.add_document(tmp_path / "x.txt", "<img src=x onerror=alert(1)> hopfield " * 40, title="<b>T</b>")
    monkeypatch.setattr(html_server, "INDEX_DB", idx.db_path)
    body = html_server.search("<script>alert(1)</script> hopfield").body.decode()
    assert "<script>" not in body and "<img src=x" not in body and "<b>T</b>" not in body
    assert "&lt;script&gt;" in body
