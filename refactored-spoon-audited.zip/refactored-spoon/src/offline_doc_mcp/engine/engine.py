"""Answering engine with strict mode isolation.

Mode policy (see ``modes.py``):

* CLASSICAL, ARCHIVE and AUTO (which resolves to CLASSICAL) NEVER touch an LLM
  provider, even if one was injected or ``require_llm`` is set.
* ARCHIVE answers only with retrieved, source-bearing passages.
* RESEARCH, AUDIT and HYBRID may use the injected provider.

This package ships no rule engine and no provider discovery: a provider is only
ever one the caller passes in explicitly.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from .modes import Mode, resolve_mode

TRUTH_STATUSES = ("OFFICIAL", "CONSENSUS", "PLAUSIBLE", "SPECULATIVE", "UNKNOWN")
_STATUS_LINE = re.compile(r"^\s*TRUTH_STATUS:\s*([A-Za-z]+)\s*$", re.MULTILINE)

# A retrieval function maps a question to passages, each a dict with at least
# "content", "title" and "path" (what LocalIndex.search returns).
ArchiveSearch = Callable[[str], list[dict[str, Any]]]


@dataclass
class Answer:
    question: str
    mode: str
    answer: str
    subject: str = ""
    evidence: list[dict[str, Any]] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)
    classical: bool = True  # True when answered without an external provider
    truth_status: str = "UNKNOWN"
    error: Optional[str] = None
    version: str = "0.1.0"


def make_archive_search(index: Any, limit: int = 3) -> ArchiveSearch:
    """Adapt a ``LocalIndex`` into the Engine's retrieval function."""
    return lambda question: index.search(question, limit=limit)


def _source_label(p: dict[str, Any]) -> str:
    label = f"{p.get('title') or 'untitled'} ({p.get('path') or 'unknown path'}"
    if p.get("chunk_index") is not None:
        label += f", chunk {p['chunk_index']}"
    return label + ")"


def _evidence(passages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "source": "archive",
            "title": p.get("title"),
            "path": p.get("path"),
            "chunk_index": p.get("chunk_index"),
            "text": (p.get("content") or "")[:500],
        }
        for p in passages
    ]


def _format_passages(passages: list[dict[str, Any]]) -> str:
    return "\n\n".join(
        f"[{i}] Source: {_source_label(p)}\n{p.get('content', '')}"
        for i, p in enumerate(passages, 1)
    )


def _split_truth_status(raw: str) -> tuple[str, str]:
    """Return (clean_text, status). Status is UNKNOWN unless the provider
    stated a valid one; it is never assumed."""
    status = "UNKNOWN"
    m = None
    for m in _STATUS_LINE.finditer(raw):
        pass
    if m is not None:
        candidate = m.group(1).upper()
        if candidate in TRUTH_STATUSES:
            status = candidate
        raw = _STATUS_LINE.sub("", raw)
    return raw.strip(), status


class Engine:
    def __init__(
        self,
        provider: Optional[Any] = None,
        require_llm: bool = False,
        archive_search: Optional[ArchiveSearch] = None,
    ):
        self._provider = provider
        self.require_llm = require_llm
        self.archive_search = archive_search

    @property
    def provider(self) -> Optional[Any]:
        """The injected provider, or None. Never discovered from the
        environment; only provider-capable modes may use it."""
        return self._provider

    def _retrieve(self, question: str) -> list[dict[str, Any]]:
        if self.archive_search is None:
            return []
        return list(self.archive_search(question) or [])

    def ask(self, question: str, mode: str | Mode = "CLASSICAL") -> Answer:
        mode_spec = resolve_mode(mode)
        mode_name = mode_spec.name.value
        passages = self._retrieve(question)
        evidence = _evidence(passages)
        sources = [_source_label(p) for p in passages]

        # ---- offline path: CLASSICAL / ARCHIVE / AUTO (and no-provider case)
        provider = self.provider if mode_spec.allows_provider else None
        if provider is None:
            if mode_spec.allows_provider and self.require_llm:
                return Answer(
                    question=question,
                    mode=mode_name,
                    answer=f"{mode_name} mode requires an LLM provider but none was supplied.",
                    classical=True,
                    error="provider_required",
                )
            if not passages:
                return Answer(
                    question=question,
                    mode=mode_name,
                    answer=(
                        "No relevant, source-bearing documents were retrieved. "
                        + (
                            "Index documents, or supply a provider for this mode."
                            if mode_spec.allows_provider
                            else f"{mode_name} mode is offline-only and never calls an "
                            "LLM provider; index more documents or use RESEARCH, AUDIT "
                            "or HYBRID for model-backed answers."
                        )
                    ),
                    classical=True,
                )
            note = (
                "Retrieved documents (no provider supplied):\n\n"
                if mode_spec.allows_provider
                else "Retrieved documents:\n\n"
            )
            return Answer(
                question=question,
                mode=mode_name,
                answer=note + _format_passages(passages),
                evidence=evidence,
                sources=sources,
                classical=True,
            )

        # ---- provider path (only reached when allows_provider=True)
        user = f"Question: {question}\n\nContext:\n{_format_passages(passages) or '(none)'}"
        try:
            raw = provider.complete(mode_spec.system_addendum, user)
        except Exception as exc:  # provider failures must not look like answers
            return Answer(
                question=question,
                mode=mode_name,
                answer=f"The provider failed ({type(exc).__name__}); no answer was produced.",
                evidence=evidence,
                sources=sources,
                classical=False,
                error=f"provider_error: {type(exc).__name__}",
            )
        text, status = _split_truth_status(str(raw))
        return Answer(
            question=question,
            mode=mode_name,
            answer=text,
            evidence=evidence,
            sources=sources,
            classical=False,
            truth_status=status,
        )
