"""Local SQLite FTS index for offline search."""

from __future__ import annotations

import re
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from .chunker import chunk_text, iter_text_files


MAX_LIMIT = 50
_TOKEN = re.compile(r"\w+", re.UNICODE)


def fts_query(raw: str) -> str:
    """Turn free text into a safe FTS5 query (AND of quoted tokens).

    Raw user text must never reach MATCH: operators and punctuation such as
    ``'``, ``"``, ``-``, ``+``, ``AND``/``NOT`` raise OperationalError.
    Returns "" when the text has no searchable tokens.
    """
    return " ".join(f'"{t}"' for t in _TOKEN.findall(raw or ""))


class LocalIndex:
    def __init__(self, db_path: Path | str):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @contextmanager
    def _connect(self):
        """Commit on success, roll back on error, and always close."""
        conn = sqlite3.connect(self.db_path)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS documents (
                    id INTEGER PRIMARY KEY,
                    path TEXT UNIQUE,
                    title TEXT,
                    source TEXT
                )
                """
            )
            conn.execute(
                """
                CREATE VIRTUAL TABLE IF NOT EXISTS chunks USING fts5(
                    doc_id UNINDEXED,
                    chunk_index UNINDEXED,
                    content,
                    title,
                    path
                )
                """
            )

    def add_document(
        self,
        path: Path,
        text: str,
        title: str | None = None,
        source: str = "local",
        chunk_size: int = 1200,
        overlap: int = 150,
    ) -> int:
        title = title or path.stem
        chunks = chunk_text(text, chunk_size=chunk_size, overlap=overlap)
        if not chunks:
            return 0
        with self._connect() as conn:
            # Re-indexing replaces the document: drop its old chunks first so
            # they are neither orphaned nor duplicated.
            old = conn.execute(
                "SELECT id FROM documents WHERE path = ?", (str(path),)
            ).fetchone()
            if old is not None:
                conn.execute("DELETE FROM chunks WHERE doc_id = ?", (old[0],))
                conn.execute("DELETE FROM documents WHERE id = ?", (old[0],))
            cur = conn.execute(
                "INSERT INTO documents (path, title, source) VALUES (?, ?, ?)",
                (str(path), title, source),
            )
            doc_id = cur.lastrowid
            conn.executemany(
                "INSERT INTO chunks (doc_id, chunk_index, content, title, path) VALUES (?, ?, ?, ?, ?)",
                [(doc_id, i, ch, title, str(path)) for i, ch in enumerate(chunks)],
            )
        return len(chunks)

    def search(self, query: str, limit: int = 8) -> list[dict[str, Any]]:
        match = fts_query(query)
        if not match:
            return []
        limit = max(1, min(int(limit), MAX_LIMIT))
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                """
                SELECT content, title, path, doc_id, chunk_index, rank
                FROM chunks
                WHERE chunks MATCH ?
                ORDER BY rank
                LIMIT ?
                """,
                (match, limit),
            ).fetchall()
        return [
            {
                "content": r["content"],
                "title": r["title"],
                "path": r["path"],
                "doc_id": r["doc_id"],
                "chunk_index": r["chunk_index"],
                "score": r["rank"],
            }
            for r in rows
        ]

    def stats(self) -> dict[str, int]:
        with self._connect() as conn:
            docs = conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
            chunks = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        return {"documents": docs, "chunks": chunks}


def build_index_from_dir(
    data_root: Path,
    db_path: Path,
    chunk_size: int = 1200,
    overlap: int = 150,
) -> LocalIndex:
    idx = LocalIndex(db_path)
    for txt in iter_text_files(data_root):
        try:
            text = txt.read_text(encoding="utf-8", errors="ignore")
            idx.add_document(txt, text, chunk_size=chunk_size, overlap=overlap)
        except Exception as exc:
            print(f"[index] skip {txt}: {exc}")
    return idx
